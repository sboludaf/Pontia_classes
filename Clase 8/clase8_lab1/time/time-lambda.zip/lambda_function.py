import json
import datetime

def lambda_handler(event, context):
    """
    Lambda function for AWS Bedrock Agent to return current date and time
    """
    try:
        # Get current time in UTC
        current_time = datetime.datetime.utcnow()
        
        # Prepare response in the format expected by Bedrock Agent
        response = {
            "messageVersion": "1.0",
            "response": {
                "actionGroup": event.get("actionGroup", "TimeActions"),
                "apiPath": event.get("apiPath", "/datetime"),
                "httpMethod": event.get("httpMethod", "POST"),
                "httpStatusCode": 200,
                "responseBody": {
                    "application/json": {
                        "body": json.dumps({
                            "date": current_time.strftime("%Y-%m-%d"),
                            "time": current_time.strftime("%H:%M:%S UTC"),
                            "datetime": current_time.strftime("%Y-%m-%d %H:%M:%S UTC")
                        })
                    }
                }
            }
        }
        
        return response
        
    except Exception as e:
        return {
            "messageVersion": "1.0",
            "response": {
                "actionGroup": event.get("actionGroup", "TimeActions"),
                "apiPath": event.get("apiPath", "/datetime"),
                "httpMethod": event.get("httpMethod", "POST"),
                "httpStatusCode": 500,
                "responseBody": {
                    "application/json": {
                        "body": json.dumps({
                            "error": str(e)
                        })
                    }
                }
            }
        }
