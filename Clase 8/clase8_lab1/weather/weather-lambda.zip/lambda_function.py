import json
import urllib.parse
import urllib.request
from datetime import datetime

def geocode(place):
    q = urllib.parse.quote(place)
    url = f"https://geocoding-api.open-meteo.com/v1/search?name={q}&count=1&language=en&format=json"
    with urllib.request.urlopen(url, timeout=10) as resp:
        data = json.loads(resp.read().decode())
    if 'results' in data and len(data['results']) > 0:
        r = data['results'][0]
        return float(r['latitude']), float(r['longitude']), r.get('country', '')
    return None

def get_current_weather(lat, lon):
    url = f"https://api.open-meteo.com/v1/forecast?latitude={lat}&longitude={lon}&current_weather=true"
    with urllib.request.urlopen(url, timeout=10) as resp:
        return json.loads(resp.read().decode())

def build_result(city, country, weather_json):
    if 'current_weather' not in weather_json:
        return {
            "ok": False,
            "text": f"No se obtuvo weather data para {city}",
            "temperature_c": None
        }
    
    cw = weather_json['current_weather']
    temp = cw.get('temperature')
    wind = cw.get('windspeed')
    weather_time = cw.get('time')
    
    text = f"En {city}{(' - '+country) if country else ''} ahora mismo son {temp}°C (medido a las {weather_time}). Viento: {wind} km/h."
    
    return {
        "ok": True,
        "text": text,
        "temperature_c": temp
    }

def extract_city_from_bedrock_event(event):
    """Extract city parameter from Bedrock agent event"""
    try:
        # Check if requestBody exists
        if 'requestBody' in event:
            request_body = event['requestBody']
            if 'content' in request_body:
                content = request_body['content']
                if 'application/json' in content:
                    json_content = content['application/json']
                    if 'properties' in json_content:
                        properties = json_content['properties']
                        # properties is an array of objects with name and value
                        if isinstance(properties, list):
                            for prop in properties:
                                if prop.get('name') == 'city':
                                    return prop.get('value')
        
        # Fallback: check direct event fields
        if 'city' in event:
            return event['city']
        if 'City' in event:
            return event['City']
        
        return None
    except Exception as e:
        print(f"Error extracting city: {str(e)}")
        return None

def lambda_handler(event, context):
    print(f"Received event: {json.dumps(event)}")
    
    try:
        # Extract city from Bedrock event format
        city = extract_city_from_bedrock_event(event)
        
        if not city:
            response_body = {
                "ok": False,
                "text": "Falta el parámetro 'city'.",
                "temperature_c": None
            }
            http_status = 400
        else:
            # Geocode
            geo = geocode(city)
            if not geo:
                response_body = {
                    "ok": False,
                    "text": f"No se encontró la ubicación '{city}'.",
                    "temperature_c": None
                }
                http_status = 404
            else:
                lat, lon, country = geo
                weather = get_current_weather(lat, lon)
                response_body = build_result(city, country, weather)
                http_status = 200 if response_body["ok"] else 400
        
        # Format response for Bedrock
        action_response = {
            "actionGroup": event.get("actionGroup", ""),
            "apiPath": event.get("apiPath", "/get-current-weather"),
            "httpMethod": event.get("httpMethod", "POST"),
            "httpStatusCode": http_status,
            "responseBody": {
                "application/json": {
                    "body": json.dumps(response_body)
                }
            }
        }
        
        return {
            "messageVersion": "1.0",
            "response": action_response,
            "sessionAttributes": event.get("sessionAttributes", {}),
            "promptSessionAttributes": event.get("promptSessionAttributes", {})
        }
    
    except Exception as e:
        print(f"Error: {str(e)}")
        response_body = {
            "ok": False,
            "text": f"Error: {str(e)}",
            "temperature_c": None
        }
        
        action_response = {
            "actionGroup": event.get("actionGroup", ""),
            "apiPath": event.get("apiPath", "/get-current-weather"),
            "httpMethod": event.get("httpMethod", "POST"),
            "httpStatusCode": 500,
            "responseBody": {
                "application/json": {
                    "body": json.dumps(response_body)
                }
            }
        }
        
        return {
            "messageVersion": "1.0",
            "response": action_response,
            "sessionAttributes": event.get("sessionAttributes", {}),
            "promptSessionAttributes": event.get("promptSessionAttributes", {})
        }
